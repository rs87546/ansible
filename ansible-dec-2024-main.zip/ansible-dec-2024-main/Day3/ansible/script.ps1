Get-ComputerInfo | Select-Object -Property CsName, OsArchitecture, WindowsVersion, WindowsBuildLabEx
